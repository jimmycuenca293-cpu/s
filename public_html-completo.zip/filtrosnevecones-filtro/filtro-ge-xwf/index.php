<?php require __DIR__ . '/../../partes.php';
$ld = json_decode(<<<'JSON'
{"@context": "https://schema.org", "@graph": [{"@type": "Product", "name": "Filtro GE XWF", "image": "__BASE__/filtrosnevecones-img/ge-xwf-o.jpg", "sku": "XWF", "mpn": "XWF", "brand": {"@type": "Brand", "name": "GE"}, "description": "Filtro de agua para nevecón GE, referencia XWF. Es el filtro GE XWF, alargado, de los nevecones GE French Door más recientes. Se cambia sin herramientas. Ojo: no es igual al XWFE.", "offers": {"@type": "Offer", "url": "__BASE__/filtrosnevecones-filtro/filtro-ge-xwf/", "priceCurrency": "COP", "price": "158900", "availability": "https://schema.org/InStock", "itemCondition": "https://schema.org/NewCondition", "shippingDetails": {"@type": "OfferShippingDetails", "shippingRate": {"@type": "MonetaryAmount", "value": "0", "currency": "COP"}, "shippingDestination": {"@type": "DefinedRegion", "addressCountry": "CO"}, "deliveryTime": {"@type": "ShippingDeliveryTime", "handlingTime": {"@type": "QuantitativeValue", "minValue": 0, "maxValue": 1, "unitCode": "DAY"}, "transitTime": {"@type": "QuantitativeValue", "minValue": 1, "maxValue": 3, "unitCode": "DAY"}}}, "hasMerchantReturnPolicy": {"@type": "MerchantReturnPolicy", "applicableCountry": "CO", "returnPolicyCategory": "https://schema.org/MerchantReturnFiniteReturnWindow", "merchantReturnDays": 5, "returnMethod": "https://schema.org/ReturnByMail", "returnFees": "https://schema.org/ReturnFeesCustomerResponsibility"}}}, {"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Inicio", "item": "__BASE__/"}, {"@type": "ListItem", "position": 2, "name": "Filtros GE", "item": "__BASE__/filtrosnevecones-marca/ge/"}, {"@type": "ListItem", "position": 3, "name": "Filtro GE XWF", "item": "__BASE__/filtrosnevecones-filtro/filtro-ge-xwf/"}]}, {"@type": "HowTo", "name": "Cómo instalar el filtro de agua XWF", "totalTime": "PT3M", "supply": [{"@type": "HowToSupply", "name": "Filtro XWF"}], "tool": [{"@type": "HowToTool", "name": "Trapo"}], "step": [{"@type": "HowToStep", "position": 1, "text": "Abre la tapa del filtro.", "url": "__BASE__/filtrosnevecones-filtro/filtro-ge-xwf/#instalacion"}, {"@type": "HowToStep", "position": 2, "text": "Pon un trapo o una toalla debajo del filtro: al sacarlo caen unas gotas de agua.", "url": "__BASE__/filtrosnevecones-filtro/filtro-ge-xwf/#instalacion"}, {"@type": "HowToStep", "position": 3, "text": "Gira el filtro viejo un cuarto de vuelta hacia la izquierda (contra las manecillas del reloj) y sácalo halando derecho.", "url": "__BASE__/filtrosnevecones-filtro/filtro-ge-xwf/#instalacion"}, {"@type": "HowToStep", "position": 4, "text": "Quítale la tapa protectora al filtro nuevo.", "url": "__BASE__/filtrosnevecones-filtro/filtro-ge-xwf/#instalacion"}, {"@type": "HowToStep", "position": 5, "text": "Mételo en el mismo sitio, alineando la marca o la flecha del filtro con la del nevecón, y gíralo un cuarto de vuelta hacia la derecha hasta que quede firme. No lo fuerces.", "url": "__BASE__/filtrosnevecones-filtro/filtro-ge-xwf/#instalacion"}, {"@type": "HowToStep", "position": 6, "text": "Cierra la tapa y saca unos 12 litros de agua por el dispensador para sacar el aire y el polvo de carbón.", "url": "__BASE__/filtrosnevecones-filtro/filtro-ge-xwf/#instalacion"}, {"@type": "HowToStep", "position": 7, "text": "Reinicia el aviso: deja presionado 3 segundos el botón «Reset Water Filter» o «Filter» del panel.", "url": "__BASE__/filtrosnevecones-filtro/filtro-ge-xwf/#instalacion"}]}]}
JSON, true);
$R = resenas('ge-xwf-o');
if ($R['n']) {
    $ld['@graph'][0]['aggregateRating'] = ['@type' => 'AggregateRating', 'ratingValue' => $R['prom'], 'reviewCount' => $R['n'], 'bestRating' => 5, 'worstRating' => 1];
    $ld['@graph'][0]['review'] = array_map(fn($r) => ['@type' => 'Review', 'author' => ['@type' => 'Person', 'name' => $r['nombre']], 'datePublished' => substr($r['creado'], 0, 10),
        'reviewRating' => ['@type' => 'Rating', 'ratingValue' => (int) $r['estrellas'], 'bestRating' => 5], 'reviewBody' => $r['texto']], array_slice($R['lista'], 0, 5));
}
$json = str_replace('__BASE__', sitio()['base'], json_encode($ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG));
cabeza('Filtro GE XWF para nevera | Precio y envío gratis', 'Compra el Filtro GE XWF a $ 158.900 con envío gratis a toda Colombia en 2 días hábiles. También aparece como XWF-1. Paga con tarjeta, PSE o Nequi.', '/filtrosnevecones-filtro/filtro-ge-xwf/', '<link rel="preload" as="image" href="/filtrosnevecones-img/ge-xwf-o.webp"><meta property="og:image" content="' . sitio()['base'] . '/filtrosnevecones-img/ge-xwf-o.jpg"><script type="application/ld+json">' . $json . '</script>'); ?>
<nav class="miga"><a href="/">Inicio</a> › <a href="/filtrosnevecones-marca/ge/">Filtros GE</a> › Filtro GE XWF</nav>
<div class="prod">
  <div class="foto"><picture><source srcset="/filtrosnevecones-img/ge-xwf-o.webp" type="image/webp"><img src="/filtrosnevecones-img/ge-xwf-o.jpg" alt="Filtro GE XWF para nevecón GE" width="335" height="467" fetchpriority="high"></picture></div>
  <div class="caja">
    <h1>Filtro GE XWF</h1>
    <span class="m">Filtro de agua para nevecón GE · Interno · Referencia <span class="ref">XWF</span></span>
    <?php if ($R['n']) echo '<a href="#opiniones" style="text-decoration:none">' . estrellas_html($R['prom']) . ' <b>' . $R['prom'] . '</b> <span class="m">(' . $R['n'] . ($R['n'] === 1 ? ' opinión' : ' opiniones') . ')</span></a>'; ?>
    <span class="precio">$ 158.900</span>
    <ul class="ok"><li><b>Envío gratis</b> a toda Colombia: llega en 2 a 3 días hábiles a las principales ciudades.</li><li><b>Fácil de instalar:</b> paso a paso en esta página.</li><li>Pack anual de 2 filtros: $ 299.900 (ahorras $ 17.900).</li><li>Asesoría por WhatsApp para confirmar que es el de tu nevecón.</li></ul>
    <div class="compra"><button class="btn block" type="button" data-add="ge-xwf-o">Agregar al carrito</button><button class="btn ghost block" type="button" data-add="ge-xwf-o" data-ir="1">Comprar ahora</button><button class="link" type="button" data-add="ge-xwf-o" data-pack="1">+ Pack anual de 2 por $ 299.900 (ahorras $ 17.900)</button></div>
    <span class="m">Pago seguro en línea: tarjeta débito o crédito, PSE, Nequi o botón Bancolombia.</span><?= medios_pago_html() ?>
  </div>
</div>
<section class="caja descripcion">
  <h2>Descripción</h2>
  <p>Es el filtro GE XWF, alargado, de los nevecones GE French Door más recientes. Se cambia sin herramientas. Ojo: no es igual al XWFE.</p>
  <p>Retiene el cloro, el sedimento y las partículas que le dan mal sabor y mal olor al agua y al hielo, y ayuda a proteger la válvula y la máquina de hielo del nevecón. Rinde unos 6 meses de uso normal; después se satura y conviene cambiarlo.</p>
  <p>Si tu filtro viejo dice <b>XWF</b> o alguna de estas referencias: XWF-1, este es el tuyo.</p>
  <h3 style="margin:6px 0 0;font-size:16px">Qué incluye</h3>
  <ul class="ok"><li>1 filtro de agua XWF nuevo, en su empaque (o 2 si escoges el pack anual).</li><li>Envío gratis a toda Colombia con número de guía.</li><li>Paso a paso de instalación y asesoría por WhatsApp.</li><li>Asesoría por WhatsApp para confirmar que es el de tu nevecón.</li></ul>
</section>
<section class="caja datos">
  <h2>Ficha técnica y datos rápidos</h2>
  <p>El <b>Filtro GE XWF</b> es el filtro de agua interno para nevecones GE, también conocido como XWF-1. Cuesta $ 158.900 en <?= h(cfg()['negocio']['nombre']) ?> con envío gratis a toda Colombia (2 a 3 días hábiles en las principales ciudades). Se cambia cada 6 meses.</p>
  <dl class="dq"><dt>Referencia</dt><dd>XWF</dd><dt>Marca del nevecón</dt><dd>GE</dd><dt>Tipo</dt><dd>Interno</dd>
  <dt>Precio</dt><dd>$ 158.900 (pack de 2: $ 299.900)</dd><dt>Envío</dt><dd>Gratis a toda Colombia, 2 a 3 días hábiles en las principales ciudades</dd><dt>Instalación</dt><dd>Dentro del nevecón, 2 minutos sin herramientas</dd><dt>Duración</dt><dd>6 meses</dd>
  <dt>Equivalencias</dt><dd>XWF-1</dd></dl>
</section>
<section class="caja">
  <h2>¿Es el filtro de tu nevecón?</h2>
  <p>Busca esta referencia impresa en tu filtro viejo: <span class="ref">XWF</span>. Va por dentro del nevecón.</p>
  <p>También aparece como:</p><div class="chips"><a href="/filtrosnevecones-referencia/xwf-1/">XWF-1</a></div>
  
  <p>El de los nevecones GE French door más nuevos. No es igual al XWFE. Para confirmar que es el tuyo, mándanos la foto del filtro viejo o de la etiqueta del nevecón.</p>
  <p>Cámbialo cada 6 meses, o antes si el agua cambia de sabor, de olor o sale con poca presión. <a href="/filtrosnevecones-guia/cada-cuanto-cambiar-el-filtro-del-nevecon/">Más sobre cuándo cambiarlo</a>.</p>
</section>
<section class="caja">
  <h2>Para qué sirve el filtro XWF</h2>
  <p>Es el filtro GE XWF, alargado, de los nevecones GE French Door más recientes. Se cambia sin herramientas. Ojo: no es igual al XWFE.</p>
  <p>Es un filtro interno: va dentro del nevecón, en su alojamiento, y se cambia en menos de un minuto sin cerrar la llave del agua.</p>
  <ul class="ok"><li><b>Mejor sabor y olor:</b> retiene el cloro y los compuestos que le dan sabor a tubería al agua y al hielo.</li>
  <li><b>Hielo más claro:</b> menos sedimento y partículas en los cubos.</li>
  <li><b>Protege el nevecón:</b> el sedimento tapa la válvula de entrada y la máquina de hielo; un filtro al día las cuida.</li>
  <li><b>Más barato que el botellón:</b> un filtro rinde unos 6 meses de agua fría filtrada para toda la familia.</li></ul>
  <figure class="foto-sec"><picture><source srcset="/filtrosnevecones-img/tienda-alerta-640.webp 640w, /filtrosnevecones-img/tienda-alerta.webp 1024w" sizes="(max-width:700px) 100vw, 700px" type="image/webp"><img src="/filtrosnevecones-img/tienda-alerta.jpg" alt="Pantalla del nevecón que dice «Cambie el filtro de agua»" width="1024" height="576" loading="lazy"></picture><figcaption>🔔 Así avisa el nevecón cuando toca cambiar el filtro</figcaption></figure>
  <h3 style="margin:6px 0 0;font-size:16px">Señales de que ya toca cambiarlo</h3>
  <ul><li>Se cumplieron 6 meses desde el último cambio, o se prendió la luz de «Filter» o «Replace».</li><li>El agua o el hielo saben u huelen raro.</li><li>El dispensador echa el agua con poca presión o a chorritos.</li><li>El hielo sale pequeño, turbio o la máquina hace menos.</li></ul>
</section>
<section class="caja tutorial" id="instalacion">
  <h2>Cómo instalar el filtro XWF: paso a paso</h2>
  <dl class="dq"><dt>Dónde va</dt><dd>Dentro del refrigerador, en la esquina de arriba a la izquierda, detrás de una tapa (nevecones GE French door más nuevos).</dd><dt>Tiempo</dt><dd>2 minutos</dd><dt>Herramientas</dt><dd>Ninguna, solo un trapo.</dd></dl>
  <ol class="pasos"><li>Abre la tapa del filtro.</li><li>Pon un trapo o una toalla debajo del filtro: al sacarlo caen unas gotas de agua.</li><li>Gira el filtro viejo un cuarto de vuelta hacia la izquierda (contra las manecillas del reloj) y sácalo halando derecho.</li><li>Quítale la tapa protectora al filtro nuevo.</li><li>Mételo en el mismo sitio, alineando la marca o la flecha del filtro con la del nevecón, y gíralo un cuarto de vuelta hacia la derecha hasta que quede firme. No lo fuerces.</li><li>Cierra la tapa y saca unos 12 litros de agua por el dispensador para sacar el aire y el polvo de carbón.</li></ol>
  <p><b>Último paso:</b> Reinicia el aviso: deja presionado 3 segundos el botón «Reset Water Filter» o «Filter» del panel.</p>
  <p class="m">Consejos: el agua de los primeros vasos puede salir turbia o con burbujas, es normal y se aclara en unos minutos. Bota el primer hielo que salga después del cambio. Si gotea, saca el filtro y vuelve a meterlo derecho hasta que quede firme. Si tienes dudas, escríbenos por WhatsApp y te guiamos.</p>
</section>
<figure class="foto-sec"><picture><source srcset="/filtrosnevecones-img/tienda-agua-640.webp 640w, /filtrosnevecones-img/tienda-agua.webp 1024w" sizes="(max-width:700px) 100vw, 700px" type="image/webp"><img src="/filtrosnevecones-img/tienda-agua.jpg" alt="Mujer sirviéndose agua con hielo del dispensador del nevecón" width="1024" height="576" loading="lazy"></picture><figcaption>💧 Con el filtro nuevo, el agua y el hielo salen limpios otra vez</figcaption></figure>
<section class="caja" id="opiniones"><h2>Opiniones de compradores</h2>
<?php if ($R['n']): ?><span><?= estrellas_html($R['prom']) ?> <b><?= $R['prom'] ?> de 5</b> · <?= $R['n'] ?> <?= $R['n'] === 1 ? 'opinión' : 'opiniones' ?> de compradores reales</span>
<?php foreach ($R['lista'] as $r): ?><div class="resena"><?= estrellas_html((float) $r['estrellas']) ?> <b><?= h($r['nombre']) ?></b> <span class="m">· <?= h($r['ciudad']) ?> · <?= h(date('d/m/Y', strtotime($r['creado']))) ?></span><?= $r['texto'] !== '' ? '<p style="margin:4px 0 0">' . h($r['texto']) . '</p>' : '' ?></div><?php endforeach; ?>
<?php else: ?><p class="m">Todavía no hay opiniones de este filtro. Después de tu compra te pediremos la tuya por correo.</p><?php endif; ?>
</section>
<section style="display:flex;flex-direction:column;gap:8px">
  <h2>Preguntas frecuentes</h2>
  <details><summary>¿Cuánto cuesta el envío?</summary><p>Nada. El envío es gratis a toda Colombia y llega en unos 2 a 3 días hábiles a las principales ciudades. Mira el <a href="/filtrosnevecones-envios/">tiempo de entrega a tu ciudad</a>.</p></details>
  <details><summary>¿Es difícil de instalarlo?</summary><p>No. Se cambia en 2 minutos y sin herramientas. Sigue el paso a paso de esta página y, si tienes dudas, te asesoramos por WhatsApp.</p></details>
  <details><summary>¿Cómo pago?</summary><p>En línea, en página de pago segura: tarjeta débito o crédito, PSE, Nequi o botón Bancolombia. Te llega el recibo a tu correo.</p></details>
  <details><summary>¿Y si no me sirve?</summary><p>Tienes 5 días hábiles para retractarte con el filtro sin instalar, y la garantía legal si llega con un defecto de fábrica. Mira los <a href="/terminos.php#garantia">términos</a>.</p></details>
</section>
<section class="caja"><h2>Enviamos el XWF a toda Colombia</h2><p>Envío gratis a 127 ciudades y municipios. Estas son algunas:</p><div class="chips"><a href="/filtrosnevecones-envios/bogota-d-c/bogota/">Bogotá</a><a href="/filtrosnevecones-envios/antioquia/medellin/">Medellín</a><a href="/filtrosnevecones-envios/valle-del-cauca/cali/">Cali</a><a href="/filtrosnevecones-envios/atlantico/barranquilla/">Barranquilla</a><a href="/filtrosnevecones-envios/bolivar/cartagena/">Cartagena</a><a href="/filtrosnevecones-envios/santander/bucaramanga/">Bucaramanga</a><a href="/filtrosnevecones-envios/risaralda/pereira/">Pereira</a><a href="/filtrosnevecones-envios/caldas/manizales/">Manizales</a><a href="/filtrosnevecones-envios/quindio/armenia/">Armenia</a><a href="/filtrosnevecones-envios/tolima/ibague/">Ibagué</a><a href="/filtrosnevecones-envios/norte-de-santander/cucuta/">Cúcuta</a><a href="/filtrosnevecones-envios/magdalena/santa-marta/">Santa Marta</a><a href="/filtrosnevecones-envios/meta/villavicencio/">Villavicencio</a><a href="/filtrosnevecones-envios/huila/neiva/">Neiva</a><a href="/filtrosnevecones-envios/narino/pasto/">Pasto</a><a href="/filtrosnevecones-envios/cauca/popayan/">Popayán</a><a href="/filtrosnevecones-envios/cordoba/monteria/">Montería</a><a href="/filtrosnevecones-envios/cesar/valledupar/">Valledupar</a><a href="/filtrosnevecones-envios/sucre/sincelejo/">Sincelejo</a><a href="/filtrosnevecones-envios/boyaca/tunja/">Tunja</a><a href="/filtrosnevecones-envios/valle-del-cauca/palmira/">Palmira</a><a href="/filtrosnevecones-envios/cundinamarca/soacha/">Soacha</a><a href="/filtrosnevecones-envios/antioquia/envigado/">Envigado</a><a href="/filtrosnevecones-envios/cundinamarca/chia/">Chía</a></div><p class="m"><a href="/filtrosnevecones-envios/">Ver todas las ciudades</a></p></section>
<section style="display:flex;flex-direction:column;gap:10px"><h2>Otros filtros GE</h2><div class="grid"><a class="card" href="/filtrosnevecones-filtro/filtro-ge-mwf/"><span class="im"><picture><source srcset="/filtrosnevecones-img/ge-mwf-o-400.webp" type="image/webp"><img src="/filtrosnevecones-img/ge-mwf-o.jpg" alt="Filtro GE MWF" width="455" height="423" loading="lazy"></picture></span><b>Filtro GE MWF</b><span class="p">$ 158.900</span><span class="m">Envío gratis</span></a></div></section>
<div class="barra-compra"><span><span class="m">Filtro GE XWF</span><b>$ 158.900</b></span><button class="btn" type="button" data-add="ge-xwf-o">Agregar al carrito</button></div>
<?php pie(); ?>
