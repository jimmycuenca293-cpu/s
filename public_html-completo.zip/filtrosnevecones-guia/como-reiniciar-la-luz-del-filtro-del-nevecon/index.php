<?php require __DIR__ . '/../../partes.php';
$ld = <<<'JSON'
{"@context": "https://schema.org", "@graph": [{"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Inicio", "item": "__BASE__/"}, {"@type": "ListItem", "position": 2, "name": "Guías", "item": "__BASE__/filtrosnevecones-guia/"}, {"@type": "ListItem", "position": 3, "name": "Cómo apagar o reiniciar la luz del filtro del nevecón"}]}, {"@type": "Article", "headline": "Cómo apagar o reiniciar la luz del filtro del nevecón", "description": "Cómo reiniciar el aviso o la luz del filtro de agua en nevecones Samsung, LG, Whirlpool, GE, KitchenAid, Maytag y más marcas después de cambiar el filtro.", "inLanguage": "es-CO", "datePublished": "2026-10-15", "dateModified": "2026-10-15", "author": {"@id": "__BASE__/#tienda"}, "mainEntityOfPage": "__BASE__/filtrosnevecones-guia/como-reiniciar-la-luz-del-filtro-del-nevecon/"}]}
JSON;
cabeza('Cómo apagar o reiniciar la luz del filtro del nevecón', 'Cómo reiniciar el aviso o la luz del filtro de agua en nevecones Samsung, LG, Whirlpool, GE, KitchenAid, Maytag y más marcas después de cambiar el filtro.', '/filtrosnevecones-guia/como-reiniciar-la-luz-del-filtro-del-nevecon/', '<script type="application/ld+json">' . str_replace('__BASE__', sitio()['base'], $ld) . '</script>'); ?>
<nav class="miga"><a href="/">Inicio</a> › <a href="/filtrosnevecones-guia/">Guías</a> › Cómo apagar o reiniciar la luz del filtro del nevecón</nav>
<article class="legal"><h1>Cómo apagar o reiniciar la luz del filtro del nevecón</h1>
<p class="m">Escrito por <a href="/quienes-somos.php"><?= h(trim((string) (cfg()["tecnico"]["nombre"] ?? "")) ?: cfg()["negocio"]["nombre"]) ?></a>, técnico de neveras · Actualizado el 15 de octubre de 2026</p>
<figure class="foto-sec"><picture><source srcset="/filtrosnevecones-img/tienda-alerta-640.webp 640w, /filtrosnevecones-img/tienda-alerta.webp 1024w" sizes="(max-width:700px) 100vw, 700px" type="image/webp"><img src="/filtrosnevecones-img/tienda-alerta.jpg" alt="Pantalla del nevecón que dice «Cambie el filtro de agua»" width="1024" height="576" loading="lazy"></picture><figcaption>🔔 Así avisa el nevecón cuando toca cambiar el filtro</figcaption></figure>
<p>El aviso del filtro no mide el agua: es un contador de tiempo (casi siempre 6 meses). Por eso, después de cambiar el filtro hay que reiniciarlo a mano; si no, la luz sigue prendida aunque el filtro sea nuevo.</p>
<h2>La forma general</h2>
<p>En casi todos los modelos se deja presionado el botón del filtro durante unos <b>3 segundos</b>, hasta que la luz cambie o se apague. El botón puede llamarse «Filter», «Filter Reset», «Reset» o «Water Filter».</p>
<h2>Según la marca</h2>
<ul class="ok"><li><b>Samsung:</b> en muchos modelos se mantiene presionado «Filter Reset» o el botón «Alarm / Hold 3 sec for Filter Reset».</li>
<li><b>LG:</b> en muchos modelos se mantiene presionado «Water Filter» o «Filter Condition Reset».</li>
<li><b>Whirlpool:</b> en muchos modelos se mantiene presionado «Filter» o «Filter Reset».</li>
<li><b>GE:</b> en muchos modelos se mantiene presionado «Reset Water Filter».</li></ul>
<p>Si tu panel tiene bloqueo («Lock» o «Control Lock»), desbloquéalo primero. Los nombres cambian según el modelo; si no lo encuentras, busca en el manual la palabra «filter».</p>
<h2>¿Y si el agua sigue saliendo mal?</h2>
<p>Reiniciar la luz no cambia el filtro. Si el agua sabe mal o sale despacio, mira <a href="/filtrosnevecones-guia/por-que-el-agua-del-nevecon-sabe-mal/">por qué el agua del nevecón sabe mal</a>.</p></article>
<?php pie(); ?>
