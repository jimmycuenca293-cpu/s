<?php require __DIR__ . '/../../partes.php';
$ld = <<<'JSON'
{"@context": "https://schema.org", "@graph": [{"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Inicio", "item": "__BASE__/"}, {"@type": "ListItem", "position": 2, "name": "Guías", "item": "__BASE__/filtrosnevecones-guia/"}, {"@type": "ListItem", "position": 3, "name": "Filtro de nevecón interno o externo: ¿cuál necesito?"}]}, {"@type": "Article", "headline": "Filtro de nevecón interno o externo: ¿cuál necesito?", "description": "Diferencias entre el filtro de agua interno y el externo del nevecón, y cómo saber cuál lleva el tuyo.", "inLanguage": "es-CO", "datePublished": "2026-10-15", "dateModified": "2026-10-15", "author": {"@id": "__BASE__/#tienda"}, "mainEntityOfPage": "__BASE__/filtrosnevecones-guia/filtro-interno-o-externo/"}]}
JSON;
cabeza('Filtro de nevecón interno o externo: ¿cuál necesito?', 'Diferencias entre el filtro de agua interno y el externo del nevecón, y cómo saber cuál lleva el tuyo.', '/filtrosnevecones-guia/filtro-interno-o-externo/', '<script type="application/ld+json">' . str_replace('__BASE__', sitio()['base'], $ld) . '</script>'); ?>
<nav class="miga"><a href="/">Inicio</a> › <a href="/filtrosnevecones-guia/">Guías</a> › Filtro de nevecón interno o externo: ¿cuál necesito?</nav>
<article class="legal"><h1>Filtro de nevecón interno o externo: ¿cuál necesito?</h1>
<p class="m">Escrito por <a href="/quienes-somos.php"><?= h(trim((string) (cfg()["tecnico"]["nombre"] ?? "")) ?: cfg()["negocio"]["nombre"]) ?></a>, técnico de neveras · Actualizado el 15 de octubre de 2026</p>

<p>Los nevecones con dispensador de agua y hielo usan un filtro <b>interno</b> (va dentro del refrigerador) o uno <b>externo</b> (va en la manguera que trae el agua, por detrás del nevecón).</p>
<h2>Filtro interno</h2>
<p>Es el más común en Samsung, LG, Whirlpool, GE, KitchenAid, Maytag y más marcas. Cada marca y modelo usa una referencia propia, así que hay que comprar exactamente la que corresponde. Ejemplos: <a href="/filtrosnevecones-filtro/filtro-samsung-haf-cin-da29-00020b/">Samsung HAF-CIN</a>, <a href="/filtrosnevecones-filtro/filtro-lg-lt1000p/">LG LT1000P</a>, <a href="/filtrosnevecones-filtro/filtro-ge-mwf/">GE MWF</a>.</p>
<h2>Filtro externo</h2>
<p>Se usa en nevecones con dispensador que no traen filtro adentro, o para filtrar el agua antes de que entre. Va conectado a la manguera con racores rápidos. Ejemplos: <a href="/filtrosnevecones-filtro/filtro-samsung-externo-da29-10105j/">Samsung externo</a> y <a href="/filtrosnevecones-filtro/filtro-lg-externo-adq73693903/">LG externo</a>.</p>
<h2>¿Cuál tiene el mío?</h2>
<p>Abre el refrigerador y busca una tapa o compartimento con la palabra «Filter». Si lo encuentras, es interno. Si no hay ninguno y tu nevecón tiene dispensador, mira la manguera de atrás: si hay un cilindro conectado en la mitad, es externo.</p></article>
<?php pie(); ?>
