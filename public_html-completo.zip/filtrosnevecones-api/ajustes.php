<?php
// Ajustes de la tienda. Lo que escribas aquí manda sobre config.php. Este archivo no se ve desde internet.
return [
    'whatsapp' => '3013810242',
    'negocio'  => ['telefono' => '301 381 0242'],

    // Correo(s) donde te llegan los datos de cada pedido. Puedes poner varios separados por coma: 'uno@gmail.com, otro@gmail.com'
    'correo_avisos' => 'jimmycuenca293@gmail.com, serviciotecnicoyrepuestoscali@gmail.com',

    // FormSubmit apagado: no llegaba. Los pedidos llegan por la hoja de Google (abajo).
    'formulario' => ['activo' => false, 'proveedor' => 'formsubmit'],

    // HOJA DE PEDIDOS EN GOOGLE: la clave ya está puesta. Solo cambia PEGA-AQUI-LA-DIRECCION-/exec por la dirección que te da Google (termina en /exec).
    'hoja' => ['url' => 'PEGA-AQUI-LA-DIRECCION-/exec', 'clave' => '1rrUFGq78kLQiFFGMIcpqs7l7eE2'],

    // Llaves de Wompi (panel de Wompi > Desarrolladores): con ellas el carrito cobra VARIOS productos juntos, confirma los pagos solo y te manda el correo de «pedido pagado».
    // Sin ellas, cada producto se paga con su link de pago, de uno en uno. Llena las tres cosas con las llaves de PRODUCCIÓN (pub_prod_...).
    'wompi' => ['public_key' => '', 'integridad' => '', 'eventos' => ''],

    // Correo que SALE de la tienda (el buzón que creaste en Hostinger > Correos).
    // Pon aquí la clave de ESE buzón (la que usas para entrar a su webmail), entre las comillas de 'clave'. Es lo único que falta.
    'smtp' => [
        'host'    => 'smtp.hostinger.com',
        'puerto'  => 465,
        'usuario' => 'pedidos@filtrosaguanevecones.com',
        'clave'   => '',
    ],
];
