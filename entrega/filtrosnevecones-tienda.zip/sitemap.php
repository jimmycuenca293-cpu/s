<?php
require __DIR__ . '/filtrosnevecones-api/sitio.php';
header('Content-Type: application/xml; charset=utf-8');
$b = sitio()['base'];
$cat = catalogo();
$urls = ['/' => '1.0'];
foreach ($cat['marcas'] as $m) $urls['/filtrosnevecones-marca/' . $m['slug'] . '/'] = '0.8';
foreach ($cat['productos'] as $p) $urls['/filtrosnevecones-filtro/' . $p['slug'] . '/'] = '0.9';
foreach ($cat['paginas'] ?? [] as $u) $urls[$u] = str_starts_with($u, '/filtrosnevecones-referencia/') || str_starts_with($u, '/filtrosnevecones-nevecon/') ? '0.7' : '0.6';
$urls['/filtrosnevecones-tienda/'] = '0.9'; $urls['/quienes-somos.php'] = '0.5'; $urls['/contacto.php'] = '0.5'; $urls['/politica-de-envios.php'] = '0.3'; $urls['/terminos.php'] = '0.2'; $urls['/privacidad.php'] = '0.2'; $urls['/garantia-y-retracto.php'] = '0.3';
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";
$fotos = [];
foreach ($cat['productos'] as $id => $p) $fotos['/filtrosnevecones-filtro/' . $p['slug'] . '/'] = "/filtrosnevecones-img/$id.jpg";
foreach ($urls as $u => $pr) echo '  <url><loc>' . htmlspecialchars($b . $u) . '</loc><lastmod>' . $cat['fecha'] . '</lastmod><priority>' . $pr . '</priority>'
    . (isset($fotos[$u]) ? '<image:image><image:loc>' . htmlspecialchars($b . $fotos[$u]) . '</image:loc></image:image>' : '') . "</url>\n";
echo '</urlset>';
