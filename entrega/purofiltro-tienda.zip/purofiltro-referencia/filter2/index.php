<?php require __DIR__ . '/../../partes.php';
$ld = <<<'JSON'
{"@context": "https://schema.org", "@graph": [{"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Inicio", "item": "__BASE__/"}, {"@type": "ListItem", "position": 2, "name": "Referencias", "item": "__BASE__/purofiltro-referencias/"}, {"@type": "ListItem", "position": 3, "name": "Filtro FILTER2"}]}, {"@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": "¿El filtro FILTER2 es igual al EDR2RXD1?", "acceptedAnswer": {"@type": "Answer", "text": "Sí. FILTER2 y EDR2RXD1 son nombres de la misma referencia de filtro para nevecón Whirlpool: tienen la misma forma, la misma conexión y se cambian igual."}}, {"@type": "Question", "name": "¿Cada cuánto se cambia el filtro FILTER2?", "acceptedAnswer": {"@type": "Answer", "text": "Cada 6 meses, o antes si el agua cambia de sabor, de olor o sale con poca presión."}}, {"@type": "Question", "name": "¿Cuánto cuesta el envío del FILTER2?", "acceptedAnswer": {"@type": "Answer", "text": "Nada. El envío es gratis a toda Colombia y llega en unos 2 días hábiles después del pago. "}}]}, {"@type": "HowTo", "name": "Cómo instalar el filtro de agua FILTER2", "totalTime": "PT3M", "supply": [{"@type": "HowToSupply", "name": "Filtro FILTER2"}], "tool": [{"@type": "HowToTool", "name": "Trapo"}], "step": [{"@type": "HowToStep", "position": 1, "text": "Ubica la tapa del filtro en la rejilla de abajo, al frente.", "url": "__BASE__/purofiltro-referencia/filter2/#instalacion"}, {"@type": "HowToStep", "position": 2, "text": "Gira la tapa un cuarto de vuelta hacia la izquierda y saca el filtro viejo halándolo hacia afuera.", "url": "__BASE__/purofiltro-referencia/filter2/#instalacion"}, {"@type": "HowToStep", "position": 3, "text": "Quita la tapa del filtro viejo: se pasa al filtro nuevo, no la botes.", "url": "__BASE__/purofiltro-referencia/filter2/#instalacion"}, {"@type": "HowToStep", "position": 4, "text": "Pon la tapa en el filtro nuevo, mételo en el hueco y gira la tapa un cuarto de vuelta hacia la derecha hasta que quede alineada con la rejilla.", "url": "__BASE__/purofiltro-referencia/filter2/#instalacion"}, {"@type": "HowToStep", "position": 5, "text": "Saca unos 12 litros de agua por el dispensador para sacar el aire y el polvo de carbón.", "url": "__BASE__/purofiltro-referencia/filter2/#instalacion"}, {"@type": "HowToStep", "position": 6, "text": "Reinicia el aviso: deja presionado 3 segundos el botón «Filter Reset» o «Water Filter» del panel.", "url": "__BASE__/purofiltro-referencia/filter2/#instalacion"}]}]}
JSON;
cabeza('Filtro FILTER2 para nevecón Whirlpool | Equivale a EDR2RXD1', '¿Buscas el filtro FILTER2? Es la misma referencia que el Filtro Whirlpool EveryDrop 2 EDR2RXD1: $ 145.900 con envío gratis a toda Colombia. Paga en línea con tarjeta, PSE o Nequi.', '/purofiltro-referencia/filter2/', '<script type="application/ld+json">' . str_replace('__BASE__', sitio()['base'], $ld) . '</script>'); ?>
<nav class="miga"><a href="/">Inicio</a> › <a href="/purofiltro-referencias/">Referencias</a> › Filtro FILTER2</nav>
<h1>Filtro FILTER2 para nevecón Whirlpool</h1>
<p>El filtro <b>FILTER2</b> es la misma referencia que el <b>Filtro Whirlpool EveryDrop 2 EDR2RXD1</b>: va por dentro del nevecón. Lo tenemos a <b>$ 145.900</b> con envío gratis a toda Colombia.</p>
<div class="prod">
  <a class="foto" href="/purofiltro-filtro/filtro-whirlpool-everydrop-2-edr2rxd1/"><picture><source srcset="/purofiltro-img/wp-2-o.webp" type="image/webp"><img src="/purofiltro-img/wp-2-o.jpg" alt="Filtro Whirlpool EveryDrop 2 EDR2RXD1 para nevecón Whirlpool" width="600" height="600" fetchpriority="high"></picture></a>
  <div class="caja">
    <span class="m">Para el FILTER2 te sirve</span>
    <h2 style="margin:0">Filtro Whirlpool EveryDrop 2 EDR2RXD1</h2>
    <span class="precio">$ 145.900</span>
    <ul class="ok"><li><b>Envío gratis</b> a toda Colombia: llega en 2 a 3 días hábiles a las principales ciudades.</li><li><b>Fácil de instalar:</b> paso a paso en la página del filtro.</li><li>Asesoría por WhatsApp para confirmar que es el de tu nevecón.</li></ul>
    <div class="compra"><button class="btn block" type="button" data-add="wp-2-o">Agregar al carrito</button><button class="btn ghost block" type="button" data-add="wp-2-o" data-ir="1">Comprar ahora</button><a class="link" href="/purofiltro-filtro/filtro-whirlpool-everydrop-2-edr2rxd1/">Ver todos los detalles del filtro</a></div>
  </div>
</div>
<section class="caja">
  <h2>Equivalencias del filtro FILTER2</h2>
  <p>Estas referencias son el mismo filtro. Si tu filtro viejo trae cualquiera de ellas impresa, este es el tuyo:</p>
  <table class="t"><tr><th>Referencia</th><th>Marca</th><th>Tipo</th></tr>
  <tr><td><span class="ref">EDR2RXD1</span></td><td>Whirlpool</td><td>Interno</td></tr><tr><td><span class="ref">EDR2RXD1</span></td><td>Whirlpool</td><td>Interno</td></tr><tr><td><span class="ref">W10413645A</span></td><td>Whirlpool</td><td>Interno</td></tr><tr><td><span class="ref">W10413645</span></td><td>Whirlpool</td><td>Interno</td></tr><tr><td><span class="ref">P8RFWB2L</span></td><td>Whirlpool</td><td>Interno</td></tr><tr><td><span class="ref">46-9081</span></td><td>Whirlpool</td><td>Interno</td></tr>
  </table>
</section>
<section class="caja">
  <h2>Cómo confirmar que es tu filtro</h2>
  <ol><li>Saca el filtro viejo y busca la referencia impresa en la etiqueta: tiene que decir <span class="ref">FILTER2</span> o alguna de las equivalencias de arriba.</li>
  <li>Si no se lee, mira el modelo del nevecón en la etiqueta de adentro (en una pared lateral o en el techo del refrigerador).</li>
  <li>Si tienes dudas, escríbenos al correo con la foto del filtro viejo o de la etiqueta y te confirmamos antes de comprar.</li></ol>
</section>
<section class="caja">
  <h2>Para qué sirve el filtro FILTER2</h2>
  <p>Es el filtro EveryDrop número 2 de Whirlpool. Lo usan nevecones Whirlpool, Maytag, KitchenAid y Amana con dispensador. Va adentro del refrigerador y se cambia sin herramientas.</p>
  <p>Es un filtro interno: va dentro del nevecón, en su alojamiento, y se cambia en menos de un minuto sin cerrar la llave del agua.</p>
  <ul class="ok"><li><b>Mejor sabor y olor:</b> retiene el cloro y los compuestos que le dan sabor a tubería al agua y al hielo.</li>
  <li><b>Hielo más claro:</b> menos sedimento y partículas en los cubos.</li>
  <li><b>Protege el nevecón:</b> el sedimento tapa la válvula de entrada y la máquina de hielo; un filtro al día las cuida.</li>
  <li><b>Más barato que el botellón:</b> un filtro rinde unos 6 meses de agua fría filtrada para toda la familia.</li></ul>
  <figure class="foto-sec"><picture><source srcset="/purofiltro-img/tienda-alerta-640.webp 640w, /purofiltro-img/tienda-alerta.webp 1024w" sizes="(max-width:700px) 100vw, 700px" type="image/webp"><img src="/purofiltro-img/tienda-alerta.jpg" alt="Pantalla del nevecón que dice «Cambie el filtro de agua»" width="1024" height="576" loading="lazy"></picture><figcaption>🔔 Así avisa el nevecón cuando toca cambiar el filtro</figcaption></figure>
  <h3 style="margin:6px 0 0;font-size:16px">Señales de que ya toca cambiarlo</h3>
  <ul><li>Se cumplieron 6 meses desde el último cambio, o se prendió la luz de «Filter» o «Replace».</li><li>El agua o el hielo saben u huelen raro.</li><li>El dispensador echa el agua con poca presión o a chorritos.</li><li>El hielo sale pequeño, turbio o la máquina hace menos.</li></ul>
</section>
<section class="caja tutorial" id="instalacion">
  <h2>Cómo instalar el filtro FILTER2: paso a paso</h2>
  <dl class="dq"><dt>Dónde va</dt><dd>En la rejilla de abajo, al frente del nevecón (zócalo), en nevecones Whirlpool, Maytag, KitchenAid y Amana de dos puertas lado a lado.</dd><dt>Tiempo</dt><dd>3 minutos</dd><dt>Herramientas</dt><dd>Ninguna, solo un trapo.</dd></dl>
  <ol class="pasos"><li>Ubica la tapa del filtro en la rejilla de abajo, al frente.</li><li>Gira la tapa un cuarto de vuelta hacia la izquierda y saca el filtro viejo halándolo hacia afuera.</li><li>Quita la tapa del filtro viejo: se pasa al filtro nuevo, no la botes.</li><li>Pon la tapa en el filtro nuevo, mételo en el hueco y gira la tapa un cuarto de vuelta hacia la derecha hasta que quede alineada con la rejilla.</li><li>Saca unos 12 litros de agua por el dispensador para sacar el aire y el polvo de carbón.</li></ol>
  <p><b>Último paso:</b> Reinicia el aviso: deja presionado 3 segundos el botón «Filter Reset» o «Water Filter» del panel.</p>
  <p class="m">Consejos: el agua de los primeros vasos puede salir turbia o con burbujas, es normal y se aclara en unos minutos. Bota el primer hielo que salga después del cambio. Si gotea, saca el filtro y vuelve a meterlo derecho hasta que quede firme. Si tienes dudas, escríbenos por WhatsApp y te guiamos.</p>
</section>
<figure class="foto-sec"><picture><source srcset="/purofiltro-img/tienda-agua-640.webp 640w, /purofiltro-img/tienda-agua.webp 1024w" sizes="(max-width:700px) 100vw, 700px" type="image/webp"><img src="/purofiltro-img/tienda-agua.jpg" alt="Mujer sirviéndose agua con hielo del dispensador del nevecón" width="1024" height="576" loading="lazy"></picture><figcaption>💧 Con el filtro nuevo, el agua y el hielo salen limpios otra vez</figcaption></figure>
<p class="m">¿Otro tipo de filtro? Mira <a href="/purofiltro-instalacion/">todos los tutoriales de instalación</a>.</p>
<section style="display:flex;flex-direction:column;gap:8px"><h2>Preguntas frecuentes</h2><details><summary>¿El filtro FILTER2 es igual al EDR2RXD1?</summary><p>Sí. FILTER2 y EDR2RXD1 son nombres de la misma referencia de filtro para nevecón Whirlpool: tienen la misma forma, la misma conexión y se cambian igual.</p></details><details><summary>¿Cada cuánto se cambia el filtro FILTER2?</summary><p>Cada 6 meses, o antes si el agua cambia de sabor, de olor o sale con poca presión.</p></details><details><summary>¿Cuánto cuesta el envío del FILTER2?</summary><p>Nada. El envío es gratis a toda Colombia y llega en unos 2 días hábiles después del pago. </p></details></section>
<?php pie(); ?>
