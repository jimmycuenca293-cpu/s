<?php require __DIR__ . '/../../partes.php';
$ld = <<<'JSON'
{"@context": "https://schema.org", "@graph": [{"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "Inicio", "item": "__BASE__/"}, {"@type": "ListItem", "position": 2, "name": "Referencias", "item": "__BASE__/purofiltro-referencias/"}, {"@type": "ListItem", "position": 3, "name": "Filtro HAF-QIN"}]}, {"@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": "¿El filtro HAF-QIN es igual al DA97-17376B?", "acceptedAnswer": {"@type": "Answer", "text": "Sí. HAF-QIN y DA97-17376B son nombres de la misma referencia de filtro para nevecón Samsung: tienen la misma forma, la misma conexión y se cambian igual."}}, {"@type": "Question", "name": "¿Cada cuánto se cambia el filtro HAF-QIN?", "acceptedAnswer": {"@type": "Answer", "text": "Cada 6 meses, o antes si el agua cambia de sabor, de olor o sale con poca presión."}}, {"@type": "Question", "name": "¿Cuánto cuesta el envío del HAF-QIN?", "acceptedAnswer": {"@type": "Answer", "text": "Nada. El envío es gratis a toda Colombia y llega en unos 2 días hábiles después del pago. "}}]}, {"@type": "HowTo", "name": "Cómo instalar el filtro de agua HAF-QIN", "totalTime": "PT3M", "supply": [{"@type": "HowToSupply", "name": "Filtro HAF-QIN"}], "tool": [{"@type": "HowToTool", "name": "Trapo"}], "step": [{"@type": "HowToStep", "position": 1, "text": "Abre la tapa de la caja del filtro.", "url": "__BASE__/purofiltro-referencia/haf-qin/#instalacion"}, {"@type": "HowToStep", "position": 2, "text": "Pon un trapo o una toalla debajo del filtro: al sacarlo caen unas gotas de agua.", "url": "__BASE__/purofiltro-referencia/haf-qin/#instalacion"}, {"@type": "HowToStep", "position": 3, "text": "Gira el filtro viejo un cuarto de vuelta hacia la izquierda (contra las manecillas del reloj) y sácalo halando derecho.", "url": "__BASE__/purofiltro-referencia/haf-qin/#instalacion"}, {"@type": "HowToStep", "position": 4, "text": "Quítale la tapa protectora al filtro nuevo.", "url": "__BASE__/purofiltro-referencia/haf-qin/#instalacion"}, {"@type": "HowToStep", "position": 5, "text": "Mételo en el mismo sitio, alineando la marca o la flecha del filtro con la del nevecón, y gíralo un cuarto de vuelta hacia la derecha hasta que quede firme. No lo fuerces.", "url": "__BASE__/purofiltro-referencia/haf-qin/#instalacion"}, {"@type": "HowToStep", "position": 6, "text": "Cierra la tapa.", "url": "__BASE__/purofiltro-referencia/haf-qin/#instalacion"}, {"@type": "HowToStep", "position": 7, "text": "Saca unos 6 litros de agua por el dispensador (unos 5 minutos, con pausas) para sacar el aire y el polvo de carbón.", "url": "__BASE__/purofiltro-referencia/haf-qin/#instalacion"}, {"@type": "HowToStep", "position": 8, "text": "Reinicia el aviso: en el panel o en la pantalla del nevecón busca «Filtro» o «Filter» y deja presionado «Reset» 3 segundos; en los Family Hub se hace desde la pantalla, en Ajustes.", "url": "__BASE__/purofiltro-referencia/haf-qin/#instalacion"}]}]}
JSON;
cabeza('Filtro HAF-QIN para nevecón Samsung | Equivale a DA97-17376B', '¿Buscas el filtro HAF-QIN? Es la misma referencia que el Filtro Samsung HAF-QIN DA97-17376B: $ 115.900 con envío gratis a toda Colombia. Paga en línea con tarjeta, PSE o Nequi.', '/purofiltro-referencia/haf-qin/', '<script type="application/ld+json">' . str_replace('__BASE__', sitio()['base'], $ld) . '</script>'); ?>
<nav class="miga"><a href="/">Inicio</a> › <a href="/purofiltro-referencias/">Referencias</a> › Filtro HAF-QIN</nav>
<h1>Filtro HAF-QIN para nevecón Samsung</h1>
<p>El filtro <b>HAF-QIN</b> es la misma referencia que el <b>Filtro Samsung HAF-QIN DA97-17376B</b>: va por dentro del nevecón. Lo tenemos a <b>$ 115.900</b> con envío gratis a toda Colombia.</p>
<div class="prod">
  <a class="foto" href="/purofiltro-filtro/filtro-samsung-haf-qin-da97-17376b/"><picture><source srcset="/purofiltro-img/sam-qin-o.webp" type="image/webp"><img src="/purofiltro-img/sam-qin-o.jpg" alt="Filtro Samsung HAF-QIN DA97-17376B para nevecón Samsung" width="600" height="600" fetchpriority="high"></picture></a>
  <div class="caja">
    <span class="m">Para el HAF-QIN te sirve</span>
    <h2 style="margin:0">Filtro Samsung HAF-QIN DA97-17376B</h2>
    <span class="precio">$ 115.900</span>
    <ul class="ok"><li><b>Envío gratis</b> a toda Colombia: llega en 2 a 3 días hábiles a las principales ciudades.</li><li><b>Fácil de instalar:</b> paso a paso en la página del filtro.</li><li>Asesoría por WhatsApp para confirmar que es el de tu nevecón.</li></ul>
    <div class="compra"><button class="btn block" type="button" data-add="sam-qin-o">Agregar al carrito</button><button class="btn ghost block" type="button" data-add="sam-qin-o" data-ir="1">Comprar ahora</button><a class="link" href="/purofiltro-filtro/filtro-samsung-haf-qin-da97-17376b/">Ver todos los detalles del filtro</a></div>
  </div>
</div>
<section class="caja">
  <h2>Equivalencias del filtro HAF-QIN</h2>
  <p>Estas referencias son el mismo filtro. Si tu filtro viejo trae cualquiera de ellas impresa, este es el tuyo:</p>
  <table class="t"><tr><th>Referencia</th><th>Marca</th><th>Tipo</th></tr>
  <tr><td><span class="ref">DA97-17376B</span></td><td>Samsung</td><td>Interno</td></tr><tr><td><span class="ref">DA97-17376B</span></td><td>Samsung</td><td>Interno</td></tr><tr><td><span class="ref">DA97-08006C</span></td><td>Samsung</td><td>Interno</td></tr><tr><td><span class="ref">HAF-QIN/EXP</span></td><td>Samsung</td><td>Interno</td></tr>
  </table>
</section>
<section class="caja">
  <h2>Cómo confirmar que es tu filtro</h2>
  <ol><li>Saca el filtro viejo y busca la referencia impresa en la etiqueta: tiene que decir <span class="ref">HAF-QIN</span> o alguna de las equivalencias de arriba.</li>
  <li>Si no se lee, mira el modelo del nevecón en la etiqueta de adentro (en una pared lateral o en el techo del refrigerador).</li>
  <li>Compara el modelo con estos nevecones que usan este filtro: <a href="/purofiltro-nevecon/rf28r7351sr/">RF28R7351SR</a>, <a href="/purofiltro-nevecon/rf22r7351sg/">RF22R7351SG</a>, <a href="/purofiltro-nevecon/rf28r7201sr/">RF28R7201SR</a>, <a href="/purofiltro-nevecon/rf23m8070sr/">RF23M8070SR</a>.</li></ol>
</section>
<section class="caja">
  <h2>Para qué sirve el filtro HAF-QIN</h2>
  <p>Es el filtro Samsung de cuerpo más ancho y hombros cuadrados. Lo usan los nevecones Samsung más recientes con dispensador, incluidos varios Bespoke y Family Hub. Va adentro del refrigerador y se cambia girándolo.</p>
  <p>Es un filtro interno: va dentro del nevecón, en su alojamiento, y se cambia en menos de un minuto sin cerrar la llave del agua.</p>
  <ul class="ok"><li><b>Mejor sabor y olor:</b> retiene el cloro y los compuestos que le dan sabor a tubería al agua y al hielo.</li>
  <li><b>Hielo más claro:</b> menos sedimento y partículas en los cubos.</li>
  <li><b>Protege el nevecón:</b> el sedimento tapa la válvula de entrada y la máquina de hielo; un filtro al día las cuida.</li>
  <li><b>Más barato que el botellón:</b> un filtro rinde unos 6 meses de agua fría filtrada para toda la familia.</li></ul>
  <figure class="foto-sec"><picture><source srcset="/purofiltro-img/tienda-alerta-640.webp 640w, /purofiltro-img/tienda-alerta.webp 1024w" sizes="(max-width:700px) 100vw, 700px" type="image/webp"><img src="/purofiltro-img/tienda-alerta.jpg" alt="Pantalla del nevecón que dice «Cambie el filtro de agua»" width="1024" height="576" loading="lazy"></picture><figcaption>🔔 Así avisa el nevecón cuando toca cambiar el filtro</figcaption></figure>
  <h3 style="margin:6px 0 0;font-size:16px">Señales de que ya toca cambiarlo</h3>
  <ul><li>Se cumplieron 6 meses desde el último cambio, o se prendió la luz de «Filter» o «Replace».</li><li>El agua o el hielo saben u huelen raro.</li><li>El dispensador echa el agua con poca presión o a chorritos.</li><li>El hielo sale pequeño, turbio o la máquina hace menos.</li></ul>
</section>
<section class="caja tutorial" id="instalacion">
  <h2>Cómo instalar el filtro HAF-QIN: paso a paso</h2>
  <dl class="dq"><dt>Dónde va</dt><dd>Dentro del refrigerador, arriba, en una caja con tapa (al centro o a la derecha según el modelo, incluidos los Bespoke y Family Hub).</dd><dt>Tiempo</dt><dd>2 minutos</dd><dt>Herramientas</dt><dd>Ninguna, solo un trapo.</dd></dl>
  <ol class="pasos"><li>Abre la tapa de la caja del filtro.</li><li>Pon un trapo o una toalla debajo del filtro: al sacarlo caen unas gotas de agua.</li><li>Gira el filtro viejo un cuarto de vuelta hacia la izquierda (contra las manecillas del reloj) y sácalo halando derecho.</li><li>Quítale la tapa protectora al filtro nuevo.</li><li>Mételo en el mismo sitio, alineando la marca o la flecha del filtro con la del nevecón, y gíralo un cuarto de vuelta hacia la derecha hasta que quede firme. No lo fuerces.</li><li>Cierra la tapa.</li><li>Saca unos 6 litros de agua por el dispensador (unos 5 minutos, con pausas) para sacar el aire y el polvo de carbón.</li></ol>
  <p><b>Último paso:</b> Reinicia el aviso: en el panel o en la pantalla del nevecón busca «Filtro» o «Filter» y deja presionado «Reset» 3 segundos; en los Family Hub se hace desde la pantalla, en Ajustes.</p>
  <p class="m">Consejos: el agua de los primeros vasos puede salir turbia o con burbujas, es normal y se aclara en unos minutos. Bota el primer hielo que salga después del cambio. Si gotea, saca el filtro y vuelve a meterlo derecho hasta que quede firme. Si tienes dudas, escríbenos por WhatsApp y te guiamos.</p>
</section>
<figure class="foto-sec"><picture><source srcset="/purofiltro-img/tienda-agua-640.webp 640w, /purofiltro-img/tienda-agua.webp 1024w" sizes="(max-width:700px) 100vw, 700px" type="image/webp"><img src="/purofiltro-img/tienda-agua.jpg" alt="Mujer sirviéndose agua con hielo del dispensador del nevecón" width="1024" height="576" loading="lazy"></picture><figcaption>💧 Con el filtro nuevo, el agua y el hielo salen limpios otra vez</figcaption></figure>
<p class="m">¿Otro tipo de filtro? Mira <a href="/purofiltro-instalacion/">todos los tutoriales de instalación</a>.</p>
<section style="display:flex;flex-direction:column;gap:8px"><h2>Preguntas frecuentes</h2><details><summary>¿El filtro HAF-QIN es igual al DA97-17376B?</summary><p>Sí. HAF-QIN y DA97-17376B son nombres de la misma referencia de filtro para nevecón Samsung: tienen la misma forma, la misma conexión y se cambian igual.</p></details><details><summary>¿Cada cuánto se cambia el filtro HAF-QIN?</summary><p>Cada 6 meses, o antes si el agua cambia de sabor, de olor o sale con poca presión.</p></details><details><summary>¿Cuánto cuesta el envío del HAF-QIN?</summary><p>Nada. El envío es gratis a toda Colombia y llega en unos 2 días hábiles después del pago. </p></details></section>
<?php pie(); ?>
