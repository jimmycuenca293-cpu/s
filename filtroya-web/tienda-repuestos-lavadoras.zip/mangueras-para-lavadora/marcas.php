<?php
declare(strict_types=1);
// Encabezado y pie de las tiendas exclusivas por marca (Samsung, LG, Whirlpool, GE).
// Cada tienda solo enlaza a sus propias páginas: no se mezclan marcas.
require_once __DIR__ . '/partes.php';

// $legado: páginas comunes (carrito, pago, legales) que usan la hoja de estilo de la tienda principal
function cabeza_marca(array $M, string $titulo, string $desc, string $ruta, string $extra = '', bool $indexar = true, bool $legado = false): void
{
    $S = sitio();
    $canon = $S['base'] . $ruta;
    $b = $M['base'];
    echo '<!doctype html><html lang="es-CO"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
        . '<title>' . h($titulo) . '</title><meta name="description" content="' . h($desc) . '">' . ($indexar ? '<link rel="canonical" href="' . h($canon) . '">' : '<meta name="robots" content="noindex">')
        . '<meta property="og:type" content="website"><meta property="og:title" content="' . h($titulo) . '"><meta property="og:description" content="' . h($desc) . '"><meta property="og:url" content="' . h($canon) . '"><meta property="og:locale" content="es_CO"><meta property="og:site_name" content="' . h($M['nombre']) . '">'
        . '<meta name="theme-color" content="' . h($M['tema']) . '"><link rel="icon" href="' . h($M['icono'] ?? '/mangueras-para-lavadora/img/icono.svg') . '">'
        . '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link rel="stylesheet" href="' . h($M['fuentes']) . '">'
        . ($legado ? '<link rel="stylesheet" href="/mangueras-para-lavadora/estilo.css">' : '') . '<link rel="stylesheet" href="/mangueras-para-lavadora/marcas.css">'
        . verificacion_html() . analytics_html() . $extra . '</head><body class="m-' . h($M['clase']) . ($legado ? ' m-legado' : '') . '">' . gtm_body_html()
        . '<div class="m-anuncio"><span>✔ ' . h($M['nombre']) . ' en Colombia</span><span>🚚 Envío a toda Colombia</span><span>💵 Pago contra entrega</span></div>'
        . (function () { ob_start(); 
    $u = $_SERVER['REQUEST_URI'] ?? '/';
    $on = fn(string $p, bool $exacto = false) => ($exacto ? $u === $p : str_starts_with($u, $p)) ? ' class="on"' : '';
    $pre = str_contains($u, 'presostato');
    echo '<nav class="m-hub" aria-label="Secciones de la tienda"><div class="m-wrap">'
        . '<a href="/"' . ($u === '/' || $u === '/index.php' ? ' class="on"' : '') . '>🏠 Inicio</a>'
        . '<a href="/#filtros"' . ((str_starts_with($u, '/samsung') || str_starts_with($u, '/lg')) ? ' class="on"' : '') . '>Filtros de pelusa</a>'
        . '<a href="/bombas-de-agua/"' . (str_starts_with($u, '/bombas-de-agua') ? ' class="on"' : '') . '>Bombas de desagüe</a>'
        . '<a href="/mangueras-para-lavadora/"' . (str_starts_with($u, '/mangueras-para-lavadora') && !$pre ? ' class="on"' : '') . '>Mangueras</a>'
        . '<a href="/mangueras-para-lavadora/presostato-para-lavadora-samsung-y-lg-inverter/"' . ($pre ? ' class="on"' : '') . '>Presostatos</a>'
        . '</div></nav>';
 return ob_get_clean(); })()
        . '<header class="m-top"><div class="m-wrap">'
        . '<a class="m-logo" href="' . h($b) . '" aria-label="' . h($M['nombre']) . '"><span class="m-sello">' . logo_marca_html($M) . '</span></a>'
        . menu_marca($M)
        . '</div></header><main' . ($legado ? ' class="wrap m-legado-main"' : '') . '>';
}

// Menú del encabezado: desplegables (mangueras, guías, ciudades) en computador y menú «hamburguesa» en el celular
function menu_marca(array $M): string
{
    $b = $M['base'];
    $filtros = '';
    foreach ($M['productos'] as $p) $filtros .= '<a href="' . h($b . $p[1]) . '/">' . h($p[0]) . '</a>';
    $guias = '';
    foreach ($M['guias'] ?? [] as $g) $guias .= '<a href="' . h($g[0]) . '">' . h($g[1]) . '</a>';
    $ciudades = '';
    foreach ($M['ciudades'] ?? [] as $c) $ciudades .= '<a href="' . h($c[1]) . '">' . h($c[0]) . '</a>';
    if (!empty($M['hub'])) $ciudades .= '<a class="m-todas" href="' . h($M['hub']) . '">Ver todas las ciudades →</a>';
    $compat = '';
    foreach ($M['compat'] ?? [] as $c) $compat .= '<a href="' . h($c[1]) . '">' . (str_starts_with($c[0], 'Todas') ? '' : 'Neveras ') . h($c[0]) . '</a>';
    $mas = '';
    foreach ($M['extra'] ?? [] as $c) $mas .= '<a href="' . h($c[1]) . '">' . h($c[0]) . '</a>';
    $cart = '';
    $dd = fn(string $t, string $links) => $links === '' ? '' : '<div class="m-dd"><a href="#" onclick="return false" aria-haspopup="true">' . $t . ' <i aria-hidden="true">▾</i></a><div class="m-panel">' . $links . '</div></div>';
    return '<nav class="m-nav" aria-label="Principal">' . $dd('Mangueras', $filtros) . $dd('Guías', $guias) . $dd('Ciudades', $ciudades) . $dd('Marcas', $compat) . $dd('Más', $mas)
        . '<a class="m-ancho" href="' . h($b) . 'cual-es-mi-manguera/">¿Cuál es el mío?</a><a class="m-ancho" href="' . h($b) . 'cambio-e-instalacion/">Instalación</a>' . $cart
        . '<details class="m-burger"><summary aria-label="Abrir el menú"><span></span></summary><div class="m-bmenu">'
        . '<b>Mangueras</b>' . $filtros . '<b>Guías</b>' . $guias . '<b>Ciudades</b>' . $ciudades . ($compat ? '<b>Más marcas</b>' . $compat : '') . ($mas ? '<b>Más</b>' . $mas : '')
        . '<b>Ayuda</b><a href="' . h($b) . 'cual-es-mi-manguera/">¿Cuál es el mío?</a><a href="' . h($b) . 'cambio-e-instalacion/">Instalación</a></div></details></nav>';
}

// Logo de la marca (somos vendedor); si no hay logo, el nombre en texto
function logo_marca_html(array $M, string $clase = 'm-logo-marca'): string
{
    if (empty($M['logo'])) return '<b class="m-logo-txt">' . h($M['tienda'] ?? $M['nombre']) . '</b>';
    return '<img class="' . h($clase) . '" src="' . h($M['logo']) . '" alt="' . h($M['nombre']) . '" width="' . (int) $M['logo_w'] . '" height="' . (int) $M['logo_h'] . '">';
}

function pie_marca(array $M): void
{
    $S = sitio();
    $n = $S['negocio'];
    $b = $M['base'];
    $tel = preg_replace('/\D/', '', (string) ($M['whatsapp'] ?? (cfg()['whatsapp'] ?? '')));
    $h = '<footer class="m-pie"><div class="m-wrap m-pie-top">'
        . '<div><a class="m-logo" href="' . h($b) . '"><span class="m-sello">' . logo_marca_html($M) . '</span></a>'
        . '<p>' . h($M['nombre']) . ', con envío a todo el país y atención por WhatsApp.</p>'
        . ($tel ? '<a class="m-pie-wa" href="https://wa.me/57' . substr($tel, -10) . '" target="_blank" rel="noopener">💬 WhatsApp ' . h($M['telefono'] ?? $n['telefono']) . '</a>' : '')
        . '<span class="m-pie-hora">' . h(ucfirst($n['horario'])) . '</span></div>'
        . '<nav><b>' . h($M['nombre']) . '</b>';
    foreach ($M['productos'] as $p) $h .= '<a href="' . h($b . $p[1]) . '/">' . h($p[0]) . '</a>';
    $h .= '</nav><nav><b>Guías</b>';
    foreach ($M['guias'] ?? [] as $g) $h .= '<a href="' . h($g[0]) . '">' . h($g[1]) . '</a>';
    if (!empty($M['compat'])) {
        $h .= '</nav><nav><b>Más marcas</b>';
        foreach ($M['compat'] as $c) $h .= '<a href="' . h($c[1]) . '">' . (str_starts_with($c[0], 'Todas') ? '' : 'Neveras ') . h($c[0]) . '</a>';
        foreach ($M['extra'] ?? [] as $c) $h .= '<a href="' . h($c[1]) . '"><b>' . h($c[0]) . '</b></a>';
    }
    $h .= '</nav><nav><b>Envíos</b>';
    foreach (array_slice($M['ciudades'] ?? [], 0, 8) as $c) $h .= '<a href="' . h($c[1]) . '">' . h($M['nombre']) . ' en ' . h($c[0]) . '</a>';
    if (!empty($M['hub'])) $h .= '<a href="' . h($M['hub']) . '"><b>Todas las ciudades →</b></a>';
    $h .= '</nav><nav><b>Ayuda</b><a href="' . h($b) . 'cual-es-mi-manguera/">¿Cuál manguera es la mía?</a><a href="' . h($b) . 'cambio-e-instalacion/">Cómo cambiar la manguera</a><a href="' . h($b) . '#preguntas">Preguntas frecuentes</a>';
    foreach ($M['externos'] ?? [] as $e) $h .= '<a href="' . h($e[1]) . '" target="_blank" rel="noopener">' . h($e[0]) . ' ↗</a>';
    $h .= '</nav>'
        . '<nav><b>Compra segura</b><a href="/mangueras-para-lavadora/terminos.php">Términos y condiciones</a><a href="/mangueras-para-lavadora/privacidad.php">Tratamiento de datos</a><a href="/mangueras-para-lavadora/garantia-y-retracto.php">Garantía y retracto</a><a href="/mangueras-para-lavadora/quienes-somos.php">Quiénes somos</a></nav>'
        . '</div>'
        . '<div class="m-wrap m-pie-base"><span>© ' . date('Y') . ' ' . h($n['nombre']) . '. Precios en pesos colombianos.</span>'
        . '<span>' . h($M['nombre']) . ' y su logo son marcas registradas de su dueño y se usan solo para indicar el tipo de lavadora.</span></div></footer>';
    echo $h . whatsapp_html() . '</body></html>';
}
