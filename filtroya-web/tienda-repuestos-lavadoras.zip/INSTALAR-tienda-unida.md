# Tienda unida de repuestos para lavadoras (https://filtrosparalavadoras.click)

Un solo zip con TODO el sitio (filtros + bombas + mangueras/presostatos + portada nueva). Las direcciones que ya tenías no cambian.

1. En Hostinger abre el administrador de archivos de filtrosparalavadoras.click, entra a `public_html`.
2. **Antes de subir**, guarda una copia de `api/config.php` y de la carpeta `data/` (tienen tu correo y tus datos): este zip NO las sobrescribe, pero por si acaso.
3. Sube `tienda-repuestos-lavadoras.zip` y descomprímelo en `public_html` aceptando reemplazar.
4. Search Console: agrega los sitemaps https://filtrosparalavadoras.click/sitemap.xml, https://filtrosparalavadoras.click/bombas-de-agua/sitemap.xml y https://filtrosparalavadoras.click/mangueras-para-lavadora/sitemap.xml.
5. WhatsApp: Samsung 305 479 6329 · LG 320 510 2995 (mangueras: 305 479 6329). Para cambiarlos, edita `bombas.py`, `mangueras.py`, `lavadoras.py` y `tienda_unida.py` y vuelve a generar.
